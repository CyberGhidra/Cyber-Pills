# Descrivere la prevenzione della perdita di dati in Microsoft Purview

> **Link Microsoft Learn:** [Descrivere la prevenzione della perdita di dati in Microsoft Purview](https://learn.microsoft.com/en-us/training/modules/describe-purview-data-solutions/4-describe-data-loss-prevention)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
