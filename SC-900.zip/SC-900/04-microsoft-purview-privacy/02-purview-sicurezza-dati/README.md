# Modulo 02 – Soluzioni di sicurezza dei dati di Microsoft Purview

> **Link:** [Describe the data security solutions of Microsoft Purview](https://learn.microsoft.com/en-us/training/modules/describe-purview-data-solutions/)
> **Unità:** 10

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Classificazione dei dati in Microsoft Purview Information Protection](./02-classificazione-dati.md) |
| 03 | [Etichette di riservatezza e policy](./03-etichette-riservatezza-policy.md) |
| 04 | [Prevenzione della perdita di dati (DLP)](./04-data-loss-prevention.md) |
| 05 | [Gestione del rischio insider](./05-gestione-rischio-insider.md) |
| 06 | [Protezione adattiva](./06-protezione-adattiva.md) |
| 07 | [Data Security Posture Management](./07-data-security-posture-management.md) |
| 08 | [Indagini sulla sicurezza dei dati (Data Security Investigations)](./08-data-security-investigations.md) |
| 09 | [Verifica delle conoscenze](./09-verifica-conoscenze.md) |
| 10 | [Riepilogo](./10-riepilogo.md) |
