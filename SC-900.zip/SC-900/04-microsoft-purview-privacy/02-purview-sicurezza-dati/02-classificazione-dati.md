# Descrivere le funzionalità di classificazione dei dati di Microsoft Purview Information Protection

> **Link Microsoft Learn:** [Descrivere le funzionalità di classificazione dei dati di Microsoft Purview Information Protection](https://learn.microsoft.com/en-us/training/modules/describe-purview-data-solutions/2-identify-sensitive-data)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
