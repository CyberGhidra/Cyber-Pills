# Descrivere la gestione del rischio insider in Microsoft Purview

> **Link Microsoft Learn:** [Descrivere la gestione del rischio insider in Microsoft Purview](https://learn.microsoft.com/en-us/training/modules/describe-purview-data-solutions/5-describe-insider-risk-management)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
