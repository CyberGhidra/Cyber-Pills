# Descrivere le indagini sulla sicurezza dei dati di Microsoft Purview

> **Link Microsoft Learn:** [Descrivere le indagini sulla sicurezza dei dati di Microsoft Purview](https://learn.microsoft.com/en-us/training/modules/describe-purview-data-solutions/6b-describe-data-security-investigations)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
