# Modulo 03 – Soluzioni di conformità dei dati di Microsoft Purview

> **Link:** [Describe the data compliance solutions of Microsoft Purview](https://learn.microsoft.com/en-us/training/modules/describe-purview-risk-compliance-governance/)
> **Unità:** 9

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Audit in Microsoft Purview](./02-audit-purview.md) |
| 03 | [eDiscovery](./03-ediscovery.md) |
| 04 | [Compliance Manager](./04-compliance-manager.md) |
| 05 | [Communication Compliance](./05-communication-compliance.md) |
| 06 | [Gestione del ciclo di vita dei dati](./06-data-lifecycle-management.md) |
| 07 | [Records Management](./07-records-management.md) |
| 08 | [Verifica delle conoscenze](./08-verifica-conoscenze.md) |
| 09 | [Riepilogo](./09-riepilogo.md) |
