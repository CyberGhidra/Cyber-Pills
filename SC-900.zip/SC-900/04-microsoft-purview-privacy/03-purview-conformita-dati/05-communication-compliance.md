# Descrivere la conformità delle comunicazioni

> **Link Microsoft Learn:** [Descrivere la conformità delle comunicazioni](https://learn.microsoft.com/en-us/training/modules/describe-purview-risk-compliance-governance/5-describe-communication-compliance)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
