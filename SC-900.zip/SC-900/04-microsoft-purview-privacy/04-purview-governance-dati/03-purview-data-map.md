# Descrivere Microsoft Purview Data Map

> **Link Microsoft Learn:** [Descrivere Microsoft Purview Data Map](https://learn.microsoft.com/en-us/training/modules/describe-purview-data-governance/3a-describe-data-map)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
