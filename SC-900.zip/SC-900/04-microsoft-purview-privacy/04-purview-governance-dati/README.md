# Modulo 04 – Soluzioni di governance dei dati di Microsoft Purview

> **Link:** [Describe the data governance solutions of Microsoft Purview](https://learn.microsoft.com/en-us/training/modules/describe-purview-data-governance/)
> **Unità:** 6

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Concetti e vantaggi della governance dei dati](./02-concetti-vantaggi-governance-dati.md) |
| 03 | [Microsoft Purview Data Map](./03-purview-data-map.md) |
| 04 | [Microsoft Purview Unified Catalog](./04-purview-unified-catalog.md) |
| 05 | [Verifica delle conoscenze](./05-verifica-conoscenze.md) |
| 06 | [Riepilogo](./06-riepilogo.md) |
