# Descrivere Microsoft Purview Unified Catalog

> **Link Microsoft Learn:** [Descrivere Microsoft Purview Unified Catalog](https://learn.microsoft.com/en-us/training/modules/describe-purview-data-governance/3-describe-data-catalog)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
