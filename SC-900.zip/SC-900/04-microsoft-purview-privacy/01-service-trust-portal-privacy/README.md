# Modulo 01 – Service Trust Portal e principi di privacy Microsoft

> **Link:** [Describe Microsoft's Service Trust portal and privacy capabilities](https://learn.microsoft.com/en-us/training/modules/describe-compliance-management-capabilities-microsoft/)
> **Unità:** 6

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Il Service Trust Portal](./02-service-trust-portal.md) |
| 03 | [Principi di privacy di Microsoft](./03-principi-privacy-microsoft.md) |
| 04 | [Microsoft Priva](./04-microsoft-priva.md) |
| 05 | [Verifica delle conoscenze](./05-verifica-conoscenze.md) |
| 06 | [Riepilogo e risorse](./06-riepilogo-risorse.md) |
