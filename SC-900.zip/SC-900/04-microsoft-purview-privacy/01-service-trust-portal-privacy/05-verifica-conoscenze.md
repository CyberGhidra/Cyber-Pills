# Verifica delle conoscenze

> **Link Microsoft Learn:** [Verifica delle conoscenze](https://learn.microsoft.com/en-us/training/modules/describe-compliance-management-capabilities-microsoft/5-knowledge-check)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
