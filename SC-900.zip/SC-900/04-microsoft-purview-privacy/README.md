# 04 – Introduzione ai principi di privacy di Microsoft Purview e Microsoft

> **Link:** [Percorso di apprendimento](https://learn.microsoft.com/training/paths/describe-capabilities-of-microsoft-compliance-solutions/)

| # | Modulo |
|---|--------|
| 01 | [Service Trust Portal e principi di privacy](./01-service-trust-portal-privacy/README.md) |
| 02 | [Soluzioni di sicurezza dei dati di Microsoft Purview](./02-purview-sicurezza-dati/README.md) |
| 03 | [Soluzioni di conformità dei dati di Microsoft Purview](./03-purview-conformita-dati/README.md) |
| 04 | [Soluzioni di governance dei dati di Microsoft Purview](./04-purview-governance-dati/README.md) |
