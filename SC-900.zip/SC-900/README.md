# SC-900 – Introduzione a Microsoft Security, Compliance e Identity

> **Corso:** [SC-900T00-A](https://learn.microsoft.com/it-it/training/courses/sc-900t00/)
> **Certificazione:** [Microsoft Certified: Security, Compliance e Identity Fundamentals](https://learn.microsoft.com/it-it/credentials/certifications/security-compliance-and-identity-fundamentals/)
> **Livello:** Principiante | **Durata:** 1 giorno

---

## Struttura del corso

| # | Percorso di apprendimento | Moduli |
|---|---------------------------|--------|
| 01 | [Concetti di sicurezza, conformità e identità](./01-concetti-sicurezza-conformita-identita/README.md) | 2 |
| 02 | [Introduzione a Microsoft Entra](./02-microsoft-entra/README.md) | 4 |
| 03 | [Soluzioni di sicurezza Microsoft](./03-soluzioni-sicurezza-microsoft/README.md) | 5 |
| 04 | [Microsoft Purview e Privacy](./04-microsoft-purview-privacy/README.md) | 4 |
