# 02 – Introduzione a Microsoft Entra

> **Link:** [Percorso di apprendimento](https://learn.microsoft.com/training/paths/describe-capabilities-of-microsoft-identity-access/)

| # | Modulo |
|---|--------|
| 01 | [Funzioni e tipi di identità di Microsoft Entra ID](./01-funzioni-tipi-identita-entra-id/README.md) |
| 02 | [Funzionalità di autenticazione di Microsoft Entra ID](./02-autenticazione-entra-id/README.md) |
| 03 | [Funzionalità di gestione degli accessi di Microsoft Entra](./03-gestione-accessi-entra/README.md) |
| 04 | [Protezione dell'identità e governance di Microsoft Entra](./04-protezione-governance-identita/README.md) |
