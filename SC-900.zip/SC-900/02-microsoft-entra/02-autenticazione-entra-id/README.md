# Modulo 02 – Funzionalità di autenticazione di Microsoft Entra ID

> **Link:** [Describe the authentication capabilities of Microsoft Entra ID](https://learn.microsoft.com/en-us/training/modules/explore-authentication-capabilities/)
> **Unità:** 7

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Metodi di autenticazione](./02-metodi-autenticazione.md) |
| 03 | [Autenticazione a più fattori (MFA)](./03-autenticazione-mfa.md) |
| 04 | [Reimpostazione self-service della password (SSPR)](./04-sspr.md) |
| 05 | [Protezione e gestione delle password](./05-protezione-gestione-password.md) |
| 06 | [Verifica delle conoscenze](./06-verifica-conoscenze.md) |
| 07 | [Riepilogo e risorse](./07-riepilogo-risorse.md) |
