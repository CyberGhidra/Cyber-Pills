# Descrivere i metodi di autenticazione

> **Link Microsoft Learn:** [Descrivere i metodi di autenticazione](https://learn.microsoft.com/en-us/training/modules/explore-authentication-capabilities/2-describe-authentication-methods)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
