# Descrivere la reimpostazione self-service della password (SSPR)

> **Link Microsoft Learn:** [Descrivere la reimpostazione self-service della password (SSPR)](https://learn.microsoft.com/en-us/training/modules/explore-authentication-capabilities/4-describe-self-service-password-reset)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
