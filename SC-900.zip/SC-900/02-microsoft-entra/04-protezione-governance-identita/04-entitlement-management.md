# Descrivere la gestione dei diritti

> **Link Microsoft Learn:** [Descrivere la gestione dei diritti](https://learn.microsoft.com/en-us/training/modules/describe-identity-protection-governance-capabilities/3a-describe-entitlement-management-terms-use)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
