# Modulo 04 – Protezione dell'identità e governance di Microsoft Entra

> **Link:** [Describe the identity protection and governance capabilities of Microsoft Entra](https://learn.microsoft.com/en-us/training/modules/describe-identity-protection-governance-capabilities/)
> **Unità:** 10

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Microsoft Entra ID Governance](./02-entra-id-governance.md) |
| 03 | [Verifica degli accessi (Access Reviews)](./03-access-reviews.md) |
| 04 | [Gestione dei diritti (Entitlement Management)](./04-entitlement-management.md) |
| 05 | [Privileged Identity Management (PIM)](./05-privileged-identity-management.md) |
| 06 | [Microsoft Entra ID Protection](./06-entra-id-protection.md) |
| 07 | [Microsoft Entra Verified ID](./07-entra-verified-id.md) |
| 08 | [Integrazione con Microsoft Security Copilot](./08-integrazione-security-copilot.md) |
| 09 | [Verifica delle conoscenze](./09-verifica-conoscenze.md) |
| 10 | [Riepilogo e risorse](./10-riepilogo-risorse.md) |
