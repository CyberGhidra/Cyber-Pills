# Descrivere l'integrazione di Microsoft Entra con Microsoft Security Copilot

> **Link Microsoft Learn:** [Descrivere l'integrazione di Microsoft Entra con Microsoft Security Copilot](https://learn.microsoft.com/en-us/training/modules/describe-identity-protection-governance-capabilities/5c-describe-entra-integration-in-copilot)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
