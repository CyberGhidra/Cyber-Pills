# Descrivere Microsoft Entra ID

> **Link Microsoft Learn:** [Descrivere Microsoft Entra ID](https://learn.microsoft.com/en-us/training/modules/explore-basic-services-identity-types/2-describe-azure-active-directory)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
