# Modulo 01 – Funzioni e tipi di identità di Microsoft Entra ID

> **Link:** [Describe the function and identity types of Microsoft Entra ID](https://learn.microsoft.com/en-us/training/modules/explore-basic-services-identity-types/)
> **Unità:** 7

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Microsoft Entra ID](./02-microsoft-entra-id.md) |
| 03 | [Tipi di identità](./03-tipi-di-identita.md) |
| 04 | [Identità ibrida](./04-identita-ibrida.md) |
| 05 | [Identità esterne](./05-identita-esterne.md) |
| 06 | [Verifica delle conoscenze](./06-verifica-conoscenze.md) |
| 07 | [Riepilogo e risorse](./07-riepilogo-risorse.md) |
