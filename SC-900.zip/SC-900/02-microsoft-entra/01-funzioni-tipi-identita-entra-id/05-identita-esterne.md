# Descrivere le identità esterne

> **Link Microsoft Learn:** [Descrivere le identità esterne](https://learn.microsoft.com/en-us/training/modules/explore-basic-services-identity-types/5-describe-external-identities)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
