# Modulo 03 – Funzionalità di gestione degli accessi di Microsoft Entra

> **Link:** [Describe access management capabilities of Microsoft Entra](https://learn.microsoft.com/en-us/training/modules/explore-access-management-capabilities/)
> **Unità:** 6

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Accesso condizionale](./02-accesso-condizionale.md) |
| 03 | [Global Secure Access in Microsoft Entra](./03-global-secure-access.md) |
| 04 | [Ruoli e RBAC di Microsoft Entra](./04-ruoli-rbac-entra.md) |
| 05 | [Verifica delle conoscenze](./05-verifica-conoscenze.md) |
| 06 | [Riepilogo e risorse](./06-riepilogo-risorse.md) |
