# Riepilogo e risorse

> **Link Microsoft Learn:** [Riepilogo e risorse](https://learn.microsoft.com/en-us/training/modules/explore-access-management-capabilities/5-summary-resources)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
