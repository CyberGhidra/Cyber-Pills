# Descrivere i ruoli e il controllo degli accessi in base al ruolo (RBAC) di Microsoft Entra

> **Link Microsoft Learn:** [Descrivere i ruoli e il controllo degli accessi in base al ruolo (RBAC) di Microsoft Entra](https://learn.microsoft.com/en-us/training/modules/explore-access-management-capabilities/3-describe-azure-role-based-access-control)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
