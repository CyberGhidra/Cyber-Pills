# Descrivere Global Secure Access in Microsoft Entra

> **Link Microsoft Learn:** [Descrivere Global Secure Access in Microsoft Entra](https://learn.microsoft.com/en-us/training/modules/explore-access-management-capabilities/2a-describe-global-secure-access)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
