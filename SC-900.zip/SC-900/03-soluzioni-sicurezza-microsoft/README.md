# 03 – Introduzione alle soluzioni di sicurezza Microsoft

> **Link:** [Percorso di apprendimento](https://learn.microsoft.com/training/paths/describe-capabilities-of-microsoft-security-solutions/)

| # | Modulo |
|---|--------|
| 01 | [Microsoft Security Copilot](./01-security-copilot/README.md) |
| 02 | [Servizi di sicurezza infrastruttura Azure](./02-servizi-infrastruttura-azure/README.md) |
| 03 | [Gestione della sicurezza in Azure](./03-gestione-sicurezza-azure/README.md) |
| 04 | [Microsoft Sentinel](./04-microsoft-sentinel/README.md) |
| 05 | [Microsoft Defender XDR](./05-microsoft-defender-xdr/README.md) |
