# Modulo 05 – Protezione dalle minacce con Microsoft Defender XDR

> **Link:** [Describe threat protection with Microsoft Defender XDR](https://learn.microsoft.com/en-us/training/modules/describe-threat-protection-with-microsoft-365-defender/)
> **Unità:** 12

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Servizi Microsoft Defender XDR](./02-servizi-defender-xdr.md) |
| 03 | [Microsoft Defender for Office 365](./03-defender-office-365.md) |
| 04 | [Microsoft Defender for Endpoint](./04-defender-endpoint.md) |
| 05 | [Microsoft Defender for Cloud Apps](./05-defender-cloud-apps.md) |
| 06 | [Microsoft Defender for Identity](./06-defender-identity.md) |
| 07 | [Microsoft Defender Vulnerability Management](./07-defender-vulnerability-management.md) |
| 08 | [Microsoft Defender Threat Intelligence](./08-defender-threat-intelligence.md) |
| 09 | [Il portale Microsoft Defender](./09-portale-microsoft-defender.md) |
| 10 | [Integrazione di Copilot con Microsoft Defender XDR](./10-copilot-defender-xdr.md) |
| 11 | [Verifica delle conoscenze](./11-verifica-conoscenze.md) |
| 12 | [Riepilogo e risorse](./12-riepilogo-risorse.md) |
