# Descrivere l'integrazione di Copilot con Microsoft Defender XDR

> **Link Microsoft Learn:** [Descrivere l'integrazione di Copilot con Microsoft Defender XDR](https://learn.microsoft.com/en-us/training/modules/describe-threat-protection-with-microsoft-365-defender/7a-describe-copilot-in-defender-xdr)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
