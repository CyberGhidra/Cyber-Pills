# Descrivere la gestione della postura di sicurezza cloud (CSPM)

> **Link Microsoft Learn:** [Descrivere la gestione della postura di sicurezza cloud (CSPM)](https://learn.microsoft.com/en-us/training/modules/describe-security-management-capabilities-of-azure/4-describe-cloud-security-posture-management)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
