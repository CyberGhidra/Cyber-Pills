# Modulo 03 – Funzionalità di gestione della sicurezza in Azure

> **Link:** [Describe the security management capabilities in Azure](https://learn.microsoft.com/en-us/training/modules/describe-security-management-capabilities-of-azure/)
> **Unità:** 8

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Microsoft Defender for Cloud](./02-microsoft-defender-for-cloud.md) |
| 03 | [Policy, standard e raccomandazioni di sicurezza](./03-policy-standard-raccomandazioni.md) |
| 04 | [Cloud Security Posture Management (CSPM)](./04-cloud-security-posture-management.md) |
| 05 | [Sicurezza avanzata di Microsoft Defender for Cloud](./05-sicurezza-avanzata-defender-cloud.md) |
| 06 | [Gestione della sicurezza DevOps](./06-devops-security-management.md) |
| 07 | [Verifica delle conoscenze](./07-verifica-conoscenze.md) |
| 08 | [Riepilogo e risorse](./08-riepilogo-risorse.md) |
