# Descrivere i gruppi di sicurezza di rete di Azure (NSG)

> **Link Microsoft Learn:** [Descrivere i gruppi di sicurezza di rete di Azure (NSG)](https://learn.microsoft.com/en-us/training/modules/describe-basic-security-capabilities-azure/6-describe-azure-network-security-groups)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
