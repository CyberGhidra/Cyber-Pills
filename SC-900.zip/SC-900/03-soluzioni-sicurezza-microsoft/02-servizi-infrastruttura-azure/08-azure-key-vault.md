# Descrivere Azure Key Vault

> **Link Microsoft Learn:** [Descrivere Azure Key Vault](https://learn.microsoft.com/en-us/training/modules/describe-basic-security-capabilities-azure/8-describe-ways-azure-encrypts-data)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
