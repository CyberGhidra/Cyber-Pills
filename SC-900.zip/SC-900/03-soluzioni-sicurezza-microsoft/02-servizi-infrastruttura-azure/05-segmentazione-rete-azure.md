# Descrivere la segmentazione di rete in Azure

> **Link Microsoft Learn:** [Descrivere la segmentazione di rete in Azure](https://learn.microsoft.com/en-us/training/modules/describe-basic-security-capabilities-azure/5-describe-network-segmentation)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
