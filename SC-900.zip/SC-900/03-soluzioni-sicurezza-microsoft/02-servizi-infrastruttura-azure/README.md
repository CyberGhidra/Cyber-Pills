# Modulo 02 – Servizi di sicurezza dell'infrastruttura di base in Azure

> **Link:** [Describe core infrastructure security services in Azure](https://learn.microsoft.com/en-us/training/modules/describe-basic-security-capabilities-azure/)
> **Unità:** 10

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Azure DDoS Protection](./02-azure-ddos-protection.md) |
| 03 | [Azure Firewall](./03-azure-firewall.md) |
| 04 | [Web Application Firewall (WAF)](./04-web-application-firewall.md) |
| 05 | [Segmentazione di rete in Azure](./05-segmentazione-rete-azure.md) |
| 06 | [Azure Network Security Groups (NSG)](./06-network-security-groups.md) |
| 07 | [Azure Bastion](./07-azure-bastion.md) |
| 08 | [Azure Key Vault](./08-azure-key-vault.md) |
| 09 | [Verifica delle conoscenze](./09-verifica-conoscenze.md) |
| 10 | [Riepilogo e risorse](./10-riepilogo-risorse.md) |
