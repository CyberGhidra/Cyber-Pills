# Descrivere l'integrazione di Microsoft Sentinel con Microsoft Security Copilot

> **Link Microsoft Learn:** [Descrivere l'integrazione di Microsoft Sentinel con Microsoft Security Copilot](https://learn.microsoft.com/en-us/training/modules/describe-security-capabilities-of-azure-sentinel/4-describe-security-copilot)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
