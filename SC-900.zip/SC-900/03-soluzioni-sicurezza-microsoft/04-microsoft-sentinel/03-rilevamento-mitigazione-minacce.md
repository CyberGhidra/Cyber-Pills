# Descrivere le funzionalità di rilevamento e mitigazione delle minacce in Microsoft Sentinel

> **Link Microsoft Learn:** [Descrivere le funzionalità di rilevamento e mitigazione delle minacce in Microsoft Sentinel](https://learn.microsoft.com/en-us/training/modules/describe-security-capabilities-of-azure-sentinel/3-describe-sentinel-provide-integrated-threat-management)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
