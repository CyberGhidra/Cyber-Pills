# Modulo 04 – Funzionalità di sicurezza di Microsoft Sentinel

> **Link:** [Describe security capabilities of Microsoft Sentinel](https://learn.microsoft.com/en-us/training/modules/describe-security-capabilities-of-azure-sentinel/)
> **Unità:** 6

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Concetti di SIEM e SOAR](./02-siem-soar.md) |
| 03 | [Rilevamento e mitigazione delle minacce in Microsoft Sentinel](./03-rilevamento-mitigazione-minacce.md) |
| 04 | [Integrazione di Microsoft Sentinel con Security Copilot](./04-integrazione-security-copilot.md) |
| 05 | [Verifica delle conoscenze](./05-verifica-conoscenze.md) |
| 06 | [Riepilogo e risorse](./06-riepilogo-risorse.md) |
