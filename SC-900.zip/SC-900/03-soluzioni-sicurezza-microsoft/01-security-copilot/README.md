# Modulo 01 – Microsoft Security Copilot

> **Link:** [Describe Microsoft Security Copilot](https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/)
> **Unità:** 8

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Cos'è Microsoft Security Copilot](./02-cose-security-copilot.md) |
| 03 | [Terminologia di Microsoft Security Copilot](./03-terminologia.md) |
| 04 | [Come Security Copilot elabora i prompt](./04-elaborazione-prompt.md) |
| 05 | [Elementi di un prompt efficace](./05-prompt-efficace.md) |
| 06 | [Come abilitare Microsoft Security Copilot](./06-abilitare-security-copilot.md) |
| 07 | [Verifica delle conoscenze](./07-verifica-conoscenze.md) |
| 08 | [Riepilogo e risorse](./08-riepilogo-risorse.md) |
