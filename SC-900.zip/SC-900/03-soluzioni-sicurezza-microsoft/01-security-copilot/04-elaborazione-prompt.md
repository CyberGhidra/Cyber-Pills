# Come Security Copilot elabora le richieste di prompt

> **Link Microsoft Learn:** [Come Security Copilot elabora le richieste di prompt](https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/4-describe-how-copilot-processes-prompts)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
