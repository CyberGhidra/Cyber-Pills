# Terminologia di Microsoft Security Copilot

> **Link Microsoft Learn:** [Terminologia di Microsoft Security Copilot](https://learn.microsoft.com/en-us/training/modules/security-copilot-getting-started/3-describe-terminology)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
