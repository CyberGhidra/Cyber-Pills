# Modulo 01 – Descrizione dei concetti di sicurezza e conformità

> **Link:** [Describe security and compliance concepts](https://learn.microsoft.com/en-us/training/modules/describe-security-concepts-methodologies/)
> **Unità:** 8

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Modello di responsabilità condivisa](./02-modello-responsabilita-condivisa.md) |
| 03 | [Defense in Depth](./03-defense-in-depth.md) |
| 04 | [Modello Zero Trust](./04-modello-zero-trust.md) |
| 05 | [Crittografia e hashing](./05-crittografia-hashing.md) |
| 06 | [Concetti GRC (Governance, Risk, Compliance)](./06-grc-governance-risk-compliance.md) |
| 07 | [Verifica delle conoscenze](./07-verifica-conoscenze.md) |
| 08 | [Riepilogo e risorse](./08-riepilogo-risorse.md) |
