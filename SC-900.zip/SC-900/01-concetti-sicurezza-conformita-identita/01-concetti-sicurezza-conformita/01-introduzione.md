# Introduzione

> **Link Microsoft Learn:** [Introduzione](https://learn.microsoft.com/en-us/training/modules/describe-security-concepts-methodologies/1-introduction)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
