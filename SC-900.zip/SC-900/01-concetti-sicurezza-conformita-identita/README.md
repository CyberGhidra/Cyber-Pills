# 01 – Introduzione ai concetti relativi a sicurezza, conformità e identità

> **Link:** [Percorso di apprendimento](https://learn.microsoft.com/training/paths/describe-concepts-of-security-compliance-identity/)

| # | Modulo |
|---|--------|
| 01 | [Concetti di sicurezza e conformità](./01-concetti-sicurezza-conformita/README.md) |
| 02 | [Concetti di identità](./02-concetti-identita/README.md) |
