# Modulo 02 – Descrizione dei concetti di identità

> **Link:** [Describe identity concepts](https://learn.microsoft.com/en-us/training/modules/describe-identity-principles-concepts/)
> **Unità:** 8

| # | Unità |
|---|-------|
| 01 | [Introduzione](./01-introduzione.md) |
| 02 | [Definire autenticazione e autorizzazione](./02-autenticazione-autorizzazione.md) |
| 03 | [L'identità come perimetro di sicurezza](./03-identita-perimetro-sicurezza.md) |
| 04 | [Il ruolo del provider di identità](./04-ruolo-provider-identita.md) |
| 05 | [Servizi directory e Active Directory](./05-servizi-directory-active-directory.md) |
| 06 | [Il concetto di federazione](./06-concetto-federazione.md) |
| 07 | [Verifica delle conoscenze](./07-verifica-conoscenze.md) |
| 08 | [Riepilogo e risorse](./08-riepilogo-risorse.md) |
