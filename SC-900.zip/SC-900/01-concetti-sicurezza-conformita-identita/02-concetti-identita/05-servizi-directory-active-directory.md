# Servizi directory e Active Directory

> **Link Microsoft Learn:** [Servizi directory e Active Directory](https://learn.microsoft.com/en-us/training/modules/describe-identity-principles-concepts/5-describe-concept-of-directory-services-active-directory)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
