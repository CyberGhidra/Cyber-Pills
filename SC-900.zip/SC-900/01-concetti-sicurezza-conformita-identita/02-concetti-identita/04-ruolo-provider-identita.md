# Il ruolo del provider di identità

> **Link Microsoft Learn:** [Il ruolo del provider di identità](https://learn.microsoft.com/en-us/training/modules/describe-identity-principles-concepts/4-describe-role-identity-provider)

## Note di studio

> _Aggiungi qui le tue note personali durante lo studio._

## Concetti chiave

> _Elenca i punti più importanti da ricordare._

## Domande di ripasso

> _Scrivi le domande che ti aiutano a ripassare questo argomento._
